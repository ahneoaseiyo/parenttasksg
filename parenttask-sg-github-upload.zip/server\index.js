import express from "express";
import cors from "cors";
import { nanoid } from "nanoid";

const app = express();
const port = Number(process.env.PORT || 8787);
const host = process.env.HOST || "0.0.0.0";

app.use(cors({ origin: true }));
app.use(express.json({ limit: "1mb" }));

const state = {
  tasks: [
    {id:"task_1",child:"Arielle",level:"K1",title:"Bring one clean cardboard box",category:"Things to bring",status:"Not done",priority:"High",dueLabel:"Tomorrow"},
    {id:"task_2",child:"Arielle",level:"K1",title:"Submit Wildlings excursion consent form",category:"Consent form",status:"Not done",priority:"High",dueLabel:"Sunday"},
  ],
  broadcasts: [
    {id:"broadcast_1",title:"Return signed consent form for Garden trip",category:"Consent form",dueLabel:"28 May",sentTo:18,done:11,pending:7},
  ],
  threads: [
    {
      id:"thread_1",
      parent:"Mei Ling Tan",
      child:"Arielle",
      level:"K1",
      topic:"Consent form",
      unread:2,
      status:"Needs reply",
      messages:[
        {id:"msg_1",from:"parent",text:"Can Arielle still join if she has a mild cough?",time:"9:12 AM"},
      ],
    },
  ],
  consentSubmissions: [],
  auditEvents: [
    {id:"audit_1",time:new Date().toISOString(),actor:"System",action:"API server started",type:"System",risk:"Low"},
  ],
  settings: {
    retentionMonths:24,
    aiApprovalRequired:true,
    notificationChannels:{push:true,email:true,sms:false,whatsapp:false},
    sensitiveFieldMasking:true,
  },
};

function audit(actor, action, type="General", risk="Low"){
  const event={id:nanoid(),time:new Date().toISOString(),actor,action,type,risk};
  state.auditEvents.unshift(event);
  return event;
}

function detectLanguage(message){
  if(/[一-龥]/.test(message)) return "Mandarin";
  if(/[அ-ஹ]/.test(message)) return "Tamil";
  if(/\b(ibu bapa|borang|tarikh|terima kasih|sila)\b/i.test(message)) return "Malay";
  return "English";
}

function demoExtract(message){
  const lower=message.toLowerCase();
  const language=detectLanguage(message);
  const tasks=[];
  const pushTask=task=>{
    if(!tasks.some(t=>t.category===task.category&&t.title===task.title)) tasks.push(task);
  };
  if(lower.includes("consent")||lower.includes("permission")||lower.includes("borang")||message.includes("同意")||message.includes("சம்மத")){
    pushTask({title:"Submit excursion consent form",category:"Consent form",dueLabel:lower.includes("28 may")?"28 May":"This week",priority:"High"});
  }
  if(lower.includes("pay")||lower.includes("fee")){
    pushTask({title:"Pay school fee",category:"Payment",dueLabel:lower.includes("27 may")?"27 May":"Before due date",priority:"Medium"});
  }
  if(message.includes("亲爱")||message.includes("家长")){
    pushTask({title:"Bring one clean cardboard box",category:"Things to bring",dueLabel:"Friday",priority:"High"});
  }
  if(lower.includes("bring")||lower.includes("pack")||lower.includes("water bottle")||lower.includes("snack")||lower.includes("covered shoes")){
    pushTask({title:"Pack required items",category:"Things to bring",dueLabel:"Before activity",priority:"High"});
  }
  if(tasks.length===0) pushTask({title:"Review school reminder",category:"Reminder",dueLabel:"Soon",priority:"Medium"});
  return {language,tasks,requiresApproval:state.settings.aiApprovalRequired};
}

app.get("/health", (_req,res)=>res.json({ok:true,service:"parenttask-sg-api"}));

app.get("/api/tasks", (_req,res)=>res.json(state.tasks));
app.post("/api/tasks", (req,res)=>{
  const task={id:nanoid(),status:"Not done",...req.body};
  state.tasks.unshift(task);
  audit("Teacher",`Created task: ${task.title}`,"Task");
  res.status(201).json(task);
});
app.patch("/api/tasks/:id", (req,res)=>{
  const task=state.tasks.find(t=>t.id===req.params.id);
  if(!task)return res.status(404).json({error:"Task not found"});
  Object.assign(task,req.body);
  audit("User",`Updated task: ${task.title}`,"Task");
  res.json(task);
});

app.get("/api/broadcasts", (_req,res)=>res.json(state.broadcasts));
app.post("/api/broadcasts", (req,res)=>{
  const broadcast={id:nanoid(),sentTo:0,done:0,pending:0,...req.body};
  state.broadcasts.unshift(broadcast);
  audit("Teacher",`Sent broadcast: ${broadcast.title}`,"Broadcast");
  res.status(201).json(broadcast);
});

app.get("/api/messages/threads", (_req,res)=>res.json(state.threads));
app.post("/api/messages/threads/:id/messages", (req,res)=>{
  const thread=state.threads.find(t=>t.id===req.params.id);
  if(!thread)return res.status(404).json({error:"Thread not found"});
  const message={id:nanoid(),from:req.body.from||"teacher",text:req.body.text,time:"Just now"};
  thread.messages.push(message);
  thread.status=req.body.from==="teacher"?"Open":"Needs reply";
  thread.unread=req.body.from==="teacher"?0:thread.unread+1;
  audit(req.body.from==="teacher"?"Teacher":"Parent",`Added message in ${thread.child} thread`,"Message");
  res.status(201).json(message);
});

app.post("/api/consents", (req,res)=>{
  const submission={id:nanoid(),submittedAt:new Date().toISOString(),...req.body};
  state.consentSubmissions.unshift(submission);
  audit("Parent",`Submitted consent for ${submission.child||"child"}`,"Consent");
  res.status(201).json(submission);
});

app.post("/api/ai/extract", (req,res)=>{
  const result=demoExtract(req.body.message||"");
  audit("AI Service",`Generated ${result.tasks.length} extraction draft(s)`,"AI","Medium");
  res.json(result);
});

app.get("/api/audit", (_req,res)=>res.json(state.auditEvents));

app.get("/api/settings", (_req,res)=>res.json(state.settings));
app.patch("/api/settings", (req,res)=>{
  Object.assign(state.settings,req.body);
  audit("Centre Admin","Updated centre policy settings","Admin","Medium");
  res.json(state.settings);
});

app.listen(port, host, ()=>{
  console.log(`ParentTask SG API listening on http://${host}:${port}`);
});
