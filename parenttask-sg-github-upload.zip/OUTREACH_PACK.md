# ParentTask SG Outreach Pack

## Outreach Goal

Secure 3-5 discovery calls with preschool operators or centre leaders, then convert 1-2 centres into a small pilot.

Do not start by asking the Singapore Government to buy the app. Start by proving demand with preschool operators, centre principals, teachers, and parents. Government buyers will care more once there is pilot evidence.

## Best First Targets

### 1. Preschool operators

These are the strongest initial targets because ParentTask SG solves an operator-level problem: parent communication reliability, consent tracking, teacher admin workload, and auditability.

- PCF Sparkletots
- My First Skool / NTUC First Campus
- Skool4Kidz
- E-Bridge Pre-School
- M.Y World Preschool
- Kinderland / EtonHouse / private preschool groups

### 2. Individual centre principals

Centre principals are useful for discovery because they feel the day-to-day pain. They may not approve procurement, but they can validate the problem and introduce HQ.

### 3. Adjacent stakeholders

- Parent communities
- Early childhood educators
- Preschool admin staff
- EdTech accelerators
- GovTech / Open Innovation Platform style channels
- ECDA/MSF only after pilot traction

## Public Contact Leads Found

### PCF Sparkletots

Public contact page lists:

- Phone: +65 6244 4600
- Email: pcfhq@pcf.org.sg
- Media: pcfhq.media@pcf.org.sg
- Address: Blk 57B New Upper Changi Road, #01-1402 PCF Building, Singapore 463057
- Contact form available on their website

Suggested route: send a short partnership/pilot enquiry to the general email or contact form. Do not position it as a government sale yet.

### Skool4Kidz

Public centres page lists:

- Headquarters: 87 Marine Parade Central #03-208, Singapore 440087
- Hotline: +65 6280 2272
- Email shown on public website

Suggested route: call first to ask who handles digital parent communication tools or centre operations pilots, then send the email.

### E-Bridge Pre-School

Public location page lists:

- HQ-style address: 460 Alexandra Road, #27-04/05/06, mTower, Singapore 119963
- Phone: +65 6336 3322

Suggested route: contact HQ and ask for the operations / parent engagement / digital transformation contact.

### My First Skool

Public website confirms My First Skool is a large Singapore preschool operator with 160+ centres and over 26,500 families. Their website has contact and centre enquiry paths.

Suggested route: use the website contact path and phrase the request as a pilot/discovery conversation for reducing missed parent tasks and teacher admin workload.

## First Outreach Email

Subject: Pilot idea to reduce missed parent tasks in preschools

Hi [Name/Team],

I’m building ParentTask SG, a Singapore-focused preschool communication tool that turns school notices into clear parent action items, consent forms, payment reminders, and teacher-parent message threads.

The goal is to reduce missed parent tasks and teacher admin follow-up, while giving centres better visibility through audit logs, role-based access, and multilingual support for English, Chinese, Malay, and Tamil households.

I have a working prototype and am looking for feedback from preschool operators or centre leaders before proposing a small pilot.

Would your team be open to a 20-minute discovery call? I’d like to understand your current parent communication workflow and see whether this could be useful for your centres.

Best regards,  
[Your Name]  
[Phone]  
[Email]  
[Prototype/demo link if available]

## Short LinkedIn / Contact Form Message

Hi, I’m building ParentTask SG, a Singapore preschool tool that helps centres convert school notices into parent action checklists, consent forms, payment reminders, and teacher-parent message threads. It is designed around multilingual households, caregiver sharing, and auditability for centre admins.

I’m looking for feedback from preschool operators before running a small pilot. Who would be the right person to speak with about parent communication or centre operations?

## Phone Script

Hi, my name is [Your Name]. I’m building a Singapore preschool communication tool called ParentTask SG.

It helps centres reduce missed parent tasks by converting notices into checklists, consent forms, reminders, and message threads.

May I check who I should email about a possible discovery call or pilot discussion for parent communication / centre operations?

## Discovery Call Questions

- How do teachers currently send reminders to parents?
- Which parent tasks are missed most often?
- How much time do teachers spend following up each week?
- Do parents often ask questions through WhatsApp or informal channels?
- Are consent forms still handled manually?
- How are payment reminders handled?
- Do caregivers such as grandparents or helpers need access to some tasks?
- What would make a pilot safe enough for your centre?
- What systems are already used for parent communication?
- Who would need to approve a pilot?

## Pilot Proposal Shape

Offer a low-risk pilot:

- 1-2 centres
- 1-2 classes
- 6-8 weeks
- No real child sensitive data in the first test if they prefer
- Measure missed task reduction, response time, teacher follow-up time, parent satisfaction
- Provide centre admin report at the end

## Important Positioning

Lead with:

- Less missed tasks
- Less teacher follow-up
- Better parent clarity
- Multilingual families
- Audit trail and centre visibility

Do not lead with:

- “AI app”
- “Government will buy this”
- “Singpass integration” unless you clarify it is future-facing
- “Fully compliant” until proper legal/security review is done
