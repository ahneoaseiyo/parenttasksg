PR #39: storage failure regression fix

This package contains Claude's exact patch, verified against the GitHub PR #39 head commit 6c57bf7a2ceb8f92bb24e9d2a5eb3fbf345e6aff. All seven source-file blob SHA prefixes match the GitHub versions.

USAGE (Windows PowerShell):
1. Open a terminal in your LOCAL clone of ahneoaseiyo/parenttasksg.
2. git fetch origin
3. git switch feature/universal-message-task-mvp
4. git pull --ff-only origin feature/universal-message-task-mvp
5. Copy this folder somewhere accessible and run:
   & "C:\path\to\pr39-ready-to-apply\apply-pr39.ps1"
6. Inspect: git diff --check ; git diff --stat
7. If satisfied: git add docs/message-to-task.md src/assistant/AssistantApp.jsx src/assistant/assistant.ui.test.js src/assistant/storage.js src/assistant/storage.test.js src/assistant/views.jsx tests/assistant.spec.js
8. git commit -m "fix: handle browser storage save and clear failures"
9. git push origin feature/universal-message-task-mvp
10. Confirm updated CI workflow results on PR #39. DO NOT MERGE until reviewed.

If the patch check fails, do not force it. Your branch may have moved, or files differ from the version reviewed.
Browser tests were not run in this packaging environment. Run your existing browser test command as documented in package.json / CI after installing dependencies.
