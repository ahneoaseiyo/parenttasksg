# Apply the verified PR #39 storage-failure patch to your local repository.
# Run in PowerShell from inside the repository folder on the target branch.
$ErrorActionPreference = 'Stop'
$repo = (git rev-parse --show-toplevel 2>$null)
if ($LASTEXITCODE -ne 0 -or -not $repo) { throw 'Run this script inside your Git repository.' }
Set-Location $repo
$branch = (git branch --show-current).Trim()
if ($branch -ne 'feature/universal-message-task-mvp') {
  throw "Wrong branch: '$branch'. Switch to feature/universal-message-task-mvp first."
}
$dirty = @(git status --porcelain)
if ($dirty.Count -gt 0) { throw 'Working tree is not clean. Commit or stash changes first.' }
$patch = Join-Path $PSScriptRoot 'pr39-storage-failure-fixes.patch'
# The patch is matched against the files currently checked out.
git apply --check -- $patch
if ($LASTEXITCODE -ne 0) { throw 'Patch check failed. Nothing was changed. Stop and inspect the branch version.' }
git apply -- $patch
if ($LASTEXITCODE -ne 0) { throw 'Patch application failed. Inspect git status before proceeding.' }
Write-Host 'Patch applied. Changed files:'
git status --short
Write-Host 'Running npm test and npm run build...'
npm test
if ($LASTEXITCODE -ne 0) { throw 'npm test failed. Do not commit/push until fixed.' }
npm run build
if ($LASTEXITCODE -ne 0) { throw 'npm run build failed. Do not commit/push until fixed.' }
Write-Host 'Local checks passed. Review git diff, then commit and push manually.'
